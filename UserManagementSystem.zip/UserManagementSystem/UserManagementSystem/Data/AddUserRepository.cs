﻿using Dapper;
using System;
using System.Data.SqlClient;
using System.Data;
using System.Security.Cryptography;
using UserManagementSystem.Core;
using UserManagementSystem.Models;

namespace UserManagementSystem.Data
{
	public class AddUserRepository: IAddUserRepository
	{

		public IEnumerable<List> AddUser(UserMaster userMaster)
		{
            IDbConnection con = new SqlConnection(new ConnString().ConnectionString);

            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("Name", userMaster.Name);
                parameters.Add("Password", userMaster.Password);
                parameters.Add("Email", userMaster.EmailId);
                parameters.Add("Age", userMaster.Age);
                parameters.Add("CreatedBy", userMaster.LoginId);
                //parameters.Add("Result", dbType: DbType.String, direction: ParameterDirection.Output);
                var Result = con.Query<List>("AddUser", parameters, commandType: CommandType.StoredProcedure);
                return Result;
            }
            catch (Exception e)
            {
               return null;

            }
        }
        public int UpdateUser(string Data)
        {
            IDbConnection con = new SqlConnection(new ConnString().ConnectionString);

            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("List", Data);
                var Result = con.Query<List>("UpdateUserData", parameters, commandType: CommandType.StoredProcedure);
                return 1;
            }
            catch (Exception e)
            {
                return 0;

            }
        }
    }
	}
