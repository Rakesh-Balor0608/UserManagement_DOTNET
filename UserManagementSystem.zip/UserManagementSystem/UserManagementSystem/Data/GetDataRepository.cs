﻿using Dapper;
using System;
using System.Data;
using System.Data.SqlClient;
using UserManagementSystem.Core;
using UserManagementSystem.Models;

namespace UserManagementSystem.Data
{
	public class GetDataRepository : IGetDataRepository
	{
		public IEnumerable<UserMaster> GetList()
		{
			try
			{
				using (IDbConnection con = new SqlConnection(new ConnString().ConnectionString))
				{
					var p = new DynamicParameters();
					const string storedProcedure = "GetList";
					return con.Query<UserMaster>(storedProcedure);
				}
			}
			catch
			{
				return null;
			}
		}
	}
}
