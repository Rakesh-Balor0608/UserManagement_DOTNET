﻿using UserManagementSystem.Models;

namespace UserManagementSystem.Core
{
	public interface IAddUserRepository
	{
		IEnumerable<List> AddUser(UserMaster userMaster);
		int UpdateUser(string Data);
	}
}
