﻿using UserManagementSystem.Models;

namespace UserManagementSystem.Core
{
	public interface IGetDataRepository
	{
		//IEnumerable<Person>
		IEnumerable<UserMaster> GetList();
	}
}
