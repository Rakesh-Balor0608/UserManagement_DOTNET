﻿using System;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using UserManagementSystem.Core;
using UserManagementSystem.Models;
using System.Security.Cryptography;
using System.Xml.Linq;
using System.Text.Json;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace UserManagementSystem.Controllers
{
	public class HomeController : Controller
	{
		private readonly ILogger<HomeController> _logger;
		private readonly ILoginRepository loginRepository;
		private readonly IAddUserRepository addUserRepository;
		private readonly IGetDataRepository getDataRepository;

		public HomeController(ILogger<HomeController> logger, ILoginRepository loginRepository,
			IAddUserRepository addUserRepository, IGetDataRepository getDataRepository)
		{
			_logger = logger;
			this.loginRepository = loginRepository;
			this.addUserRepository = addUserRepository;
			this.getDataRepository = getDataRepository;
		}
		[HttpGet]
		public IActionResult Index()
		{
			return View();
		}
		[HttpPost]
		public IActionResult Index(UserMaster userMaster)
		{
            if (TempData.ContainsKey("LoginId"))
                userMaster.LoginId = TempData["LoginId"].ToString(); 

			var list= addUserRepository.AddUser(userMaster);
			return RedirectToAction("List", "Home");
        }
		public IActionResult List()
		{
			IEnumerable<UserMaster> userMaster= getDataRepository.GetList();
			return View("List",userMaster);
		}
		public IActionResult Login()
		{
			return View();
		}
		[HttpPost]
		public ActionResult Login(LoginMaster userMasterModel)
		{
			var LoginId=userMasterModel.LoginId;
			var Password =userMasterModel.Password;
			if (LoginId!=null&&Password!=null)
			{
				var result = loginRepository.Login(userMasterModel);
				if (result == 1)
				{
					TempData["LoginId"] = LoginId;
                    return RedirectToAction("Index", "Home");
				}
				else if (result ==2)
				{
                    ModelState.AddModelError("Password", "Incorrect password.");

                    return View();
                }
				else
				{
                    ModelState.AddModelError("UserId", "Incorrect UserId.");

                    return View();
                }
			}
			else
			{
				if (LoginId == null && Password == null)
				{
					ModelState.AddModelError("LoginId", "Login Id is required.");
					ModelState.AddModelError("Password", "Password is required.");
				}
				else if(LoginId != null && Password == null)
				{
                    ModelState.AddModelError("Password", "Password is required.");
                }
				else
				{
                    ModelState.AddModelError("LoginId", "Login Id is required.");
                }
                return View();
            }
        }

        public IActionResult Privacy()
		{
			return View();
		}
        public IActionResult UpdateData(string parameter)
		{
			string LoginId, Parameter;
            if (TempData.ContainsKey("LoginId"))
            {
                LoginId = TempData["LoginId"].ToString();
                JObject json = JObject.Parse(parameter);
                json.Add(new JProperty("LoginId", LoginId));
                parameter = JsonConvert.SerializeObject(json, Formatting.Indented);
            }
            var x = addUserRepository.UpdateUser(parameter);
			return Json(x);
		}

		[ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
		public IActionResult Error()
		{
			return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
		}
	}
}