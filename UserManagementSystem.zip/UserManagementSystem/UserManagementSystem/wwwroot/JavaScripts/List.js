﻿
    function editRecord(id,name,email) {
        debugger
        $("#Id").val(id)
        $("#Name").val(name)
        $("#Email").val(email)
        $('#EditModel').modal('show');

    }

    function deleteRecord(id) {
        debugger
        alert("Delete Clicked!")
}
$(document).ready(function () {
    $("#PopUpUpdate").click(function () {
        debugger
        var id = $("#Id").val()
        var Name = $("#Name").val()
        var Email = $("#Email").val()
        var data = {
            "id": id,
            "Name": Name,
            "Email": Email
        };
        var jsonString = JSON.stringify(data);
        $('#EditModel').modal('hide');
        $.ajax({
            url: '/Home/UpdateData',
            type: 'POST',
            data: { parameter: jsonString },
            dataType: 'json',
            success: function (result) {
                if (result == 1) {
                    location.reload();
                }
            }
        });
    })
})