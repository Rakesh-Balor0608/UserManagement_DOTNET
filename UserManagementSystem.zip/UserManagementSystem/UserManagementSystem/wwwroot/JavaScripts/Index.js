﻿var selectedBloodGroup
$(document).ready(function () {
    $("#cancle").click(function () {
        alert("Cancel?")
    })
    $("#save").click(function () {
        debugger
        $('#SaveModel').modal('show');
    })
    $("#submit").click(function () {
        debugger
        $('#SubmitModel').modal('show');
    })
    $("#PopUpSubmit").click(function () {
        debugger
        debugger
        var isvalid = true;
        password = $("#Password").val()
        ConformPassword = $("#ConformPassword").val()
        password == ConformPassword ? isvalid = true : isvalid = false
        if (isvalid)
            $('#AddPage').submit();
    })

    /*
    if (isvalid) {
            $('#AddPage').submit();
        }
    
    */
    $("#bloodGroup button").click(function () {
        selectedBloodGroup  = $(this).text();
    })
})
function openPopup() {
    debugger
    
}