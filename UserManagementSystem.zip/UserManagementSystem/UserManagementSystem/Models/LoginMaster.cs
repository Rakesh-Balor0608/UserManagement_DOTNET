﻿using System.ComponentModel.DataAnnotations;

namespace UserManagementSystem.Models
{
    public class LoginMaster
    {
        [Required(ErrorMessage = "Enter Login Id")]
        public string LoginId { get; set; }
        [Required(ErrorMessage = "Enter Password")]
        public string Password { get; set; }
    }
}
