﻿namespace UserManagementSystem.Models
{
    public class UserMaster
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string EmailId { get; set; }
        public string Password { get; set; }
        public string ConformPassword { get; set; }
        public string Age {get; set; }
        public string LoginId { get; set; }
      //  public string  { get; set; }
	}
    public class List
    {
        public  string JsonList { get; set; }
    }
}
